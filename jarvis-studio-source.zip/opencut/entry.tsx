import React,{Component,useEffect} from 'react';
import {createRoot} from 'react-dom/client';
import {ThemeProvider} from 'next-themes';
import {TooltipProvider} from './src/components/ui/tooltip';
import {Toaster} from './src/components/ui/sonner';
import Editor from './src/app/editor/[project_id]/page';
import Projects from './src/app/projects/page';
import {usePathname} from './compat/navigation';
import {initializeGpuRenderer} from './src/services/renderer/gpu-renderer';
import './src/app/globals.css';
import './integration.css';
class Boundary extends Component<{children:React.ReactNode},{error:string}>{state={error:''};static getDerivedStateFromError(e:Error){return {error:e.message};}render(){return this.state.error?<main style={{padding:32}}><h1>Não foi possível abrir o OpenCut</h1><p>{this.state.error}</p><a href="/studio">Abrir Jarvis Studio</a></main>:this.props.children;}}
function App(){const pathname=usePathname();useEffect(()=>{initializeGpuRenderer().catch(console.error);},[]);return <ThemeProvider attribute="class" defaultTheme="dark"><TooltipProvider><Toaster/><Boundary>{pathname.includes('/editor/')?<Editor/>:<Projects/>}</Boundary></TooltipProvider></ThemeProvider>;}
createRoot(document.getElementById('root')!).render(<App/>);
