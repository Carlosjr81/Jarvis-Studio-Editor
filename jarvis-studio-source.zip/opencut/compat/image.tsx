import React from 'react';
export default function Image({fill,priority,unoptimized,quality,loader,placeholder,blurDataURL,style,...props}:any){return <img {...props} style={{...(fill?{position:'absolute',inset:0,width:'100%',height:'100%'}:{}),...style}}/>;}
