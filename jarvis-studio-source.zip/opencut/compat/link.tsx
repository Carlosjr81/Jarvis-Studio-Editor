import React from 'react';
import {route,useRouter} from './navigation';
export default function Link({href,onClick,prefetch,children,...props}:any){const router=useRouter();return <a {...props} href={route(String(href))} onClick={e=>{onClick?.(e);if(!e.defaultPrevented&&props.target!=='_blank'&&!e.metaKey&&!e.ctrlKey&&String(href).startsWith('/')&&(String(href).includes('editor')||href==='/projects'||href==='/')){e.preventDefault();router.push(String(href));}}}>{children}</a>;}
