import {useSyncExternalStore} from 'react';
function path(){return location.pathname;}
function subscribe(fn:()=>void){window.addEventListener('popstate',fn);return ()=>window.removeEventListener('popstate',fn);}
export const route=(value:string)=>value.startsWith('/editor/')||value==='/projects'?'/opencut'+value:value==='/'?'/opencut/projects':value;
function go(value:string,replace=false){history[replace?'replaceState':'pushState']({},'',route(value));window.dispatchEvent(new PopStateEvent('popstate'));}
const router={push:(value:string)=>go(value),replace:(value:string)=>go(value,true),back:()=>history.back(),refresh:()=>location.reload(),prefetch:()=>{}};
export function useRouter(){return router;}
export function usePathname(){return useSyncExternalStore(subscribe,path,path);}
export function useParams(){const p=usePathname();return {project_id:p.split('/editor/')[1]};}
