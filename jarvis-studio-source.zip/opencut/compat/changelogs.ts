// The integrated editor is pinned; it does not display unrelated upstream release notifications.
export const allChangelogs:any[]=[];
