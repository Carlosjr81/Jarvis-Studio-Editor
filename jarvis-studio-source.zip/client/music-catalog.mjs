// Names, filenames and ISRCs verified against the publisher's pieces.json.
export const musicCatalog=[
 {id:'exhilarate',title:'Exhilarate',filename:'Exhilarate.mp3',isrc:'USUAN1300028',mood:'Rock · treino intenso',bpm:170},
 {id:'wallpaper',title:'Wallpaper',filename:'Wallpaper.mp3',isrc:'USUAN1100843',mood:'Melódica · relaxar',bpm:92},
 {id:'cipher',title:'Cipher',filename:'Cipher2.mp3',isrc:'USUAN1100844',mood:'Eletrônica · energia',bpm:150},
 {id:'local-forecast',title:'Local Forecast - Slower',filename:'Local Forecast - Slower.mp3',isrc:'USUAN1300011',mood:'Jazz · descontraído',bpm:77},
 {id:'on-the-ground',title:'On the Ground',filename:'On the Ground.mp3',isrc:'USUAN1400030',mood:'Groove · ritmo',bpm:106},
 {id:'rising',title:'Rising',filename:'Rising.mp3',isrc:'USUAN1100754',mood:'Cinemática · suspense',bpm:84}
].map(t=>({...t,author:'Kevin MacLeod',license:'CC BY 4.0',licenseURL:'https://creativecommons.org/licenses/by/4.0/',sourceURL:'https://incompetech.com/music/royalty-free/index.html?isrc='+t.isrc,downloadURL:'https://incompetech.com/music/royalty-free/mp3-royaltyfree/'+encodeURIComponent(t.filename)}));
export function musicCredit(t){return `"${t.title}" — Kevin MacLeod (incompetech.com)\n${t.sourceURL}\nLicença CC BY 4.0: ${t.licenseURL}\nAdaptação no vídeo: trecho, volume e fades conforme a edição.`;}
export function projectMusicCredits(project){const seen=new Set();return (project.layers||[]).filter(l=>l.kind==='audio'&&l.source?.catalogId).flatMap(l=>{const t=musicCatalog.find(t=>t.id===l.source.catalogId);if(!t||seen.has(t.id))return [];seen.add(t.id);return [musicCredit(t)];}).join('\n\n');}
