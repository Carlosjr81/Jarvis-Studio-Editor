import {layer,copy,uid,clamp} from './core.mjs';
export function sourceURL(raw){
 const u=new URL(raw);if(u.protocol!=='https:'||u.username||u.password||u.port&&u.port!=='443')throw Error('Use um link HTTPS sem credenciais.');
 const h=u.hostname.toLowerCase();let videoId=null;
 if(['youtube.com','www.youtube.com','m.youtube.com','youtu.be','www.youtu.be'].includes(h)){
  videoId=h.endsWith('youtu.be')?u.pathname.split('/')[1]:u.pathname==='/watch'?u.searchParams.get('v'):u.pathname.match(/^\/(?:shorts|embed|live)\/([^/]+)/)?.[1];
  if(!/^[a-zA-Z0-9_-]{11}$/.test(videoId||''))throw Error('Use o link de um vídeo específico do YouTube.');
  return {url:'https://www.youtube.com/watch?v='+videoId,platform:'YouTube',videoId};
 }
 if(['instagram.com','www.instagram.com'].includes(h)){u.hash='';u.search='';return {url:u.href,platform:'Instagram',videoId:null};}
 if(!h.includes('.')||/^(?:localhost|127\.|0\.|10\.|192\.168\.|169\.254\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(h)||h.startsWith('['))throw Error('Use o link público da referência.');
 return {url:u.href,platform:'Página / arquivo',videoId:null};
}
export function mediaIds(p){return new Set([...p.layers.map(l=>l.assetId),...(p.referenceAssetIds||[]),...(p.alternatives||[]).map(l=>l.assetId)].filter(Boolean));}
export function makeReturnedLayer(result,a){
 const rawStart=Number(result.start),start=Number.isFinite(rawStart)?clamp(rawStart,0,86399):0;
 const requested=Number(result.duration),sourceDuration=Number(a.duration),duration=result.kind==='image'?(requested>0?requested:5):requested>0?Math.min(requested,sourceDuration):sourceDuration;
 if(!['image','video','audio'].includes(result.kind)||!Number.isFinite(duration)||duration<=0)throw Error('Resultado sem tipo ou duração válidos.');
 return layer(result.kind,{name:result.name,assetId:a.id,start,duration:Math.min(duration,86400-start),source:result.source||null});
}
export function applyReturnedLayer(p,result,a,job){
 if((p.appliedResultIds||[]).includes(result.id))return null;
 const n=makeReturnedLayer(result,a);let message='Camada adicionada';
 if(job.outputPlacement==='background'&&n.kind!=='audio'){p.layers.unshift(n);message='Fundo adicionado';}
 else if(job.outputPlacement==='replace_selected'){
  const i=p.layers.findIndex(l=>l.id===job.target?.id),old=p.layers[i];
  if(old&&!old.locked&&old.assetId===job.target.assetId&&old.start===job.target.start&&old.duration===job.target.duration&&['video','image'].includes(old.kind)&&n.kind===old.kind){
   p.alternatives=[...(p.alternatives||[]),copy(old)].slice(-50);n.start=old.start;n.duration=Math.min(n.duration,old.duration);p.layers.splice(i,1,n);message='Versão substituída; original preservado';
  }else{p.layers.push(n);message='Nova camada adicionada; a camada alvo mudou ou não é compatível';}
 }else p.layers.push(n);
 p.appliedResultIds=[...(p.appliedResultIds||[]),result.id];return {layer:n,message};
}
export function sceneProfile(name,referenceIds,notes){return {id:uid(),name:String(name).slice(0,100),referenceIds:[...new Set(referenceIds)].slice(0,50),notes:String(notes).slice(0,4000),createdAt:new Date().toISOString()};}
