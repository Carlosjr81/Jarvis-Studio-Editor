export const localFunctions=[
 ['import','Importar vídeo, foto ou áudio','Comece com os arquivos do celular ou computador.','importar upload arquivo mídia biblioteca'],
 ['new','Novo projeto','Começar uma edição vazia.','novo começar'],
 ['text','Adicionar texto','Texto editável na prévia e na linha do tempo.','texto título escrever'],
 ['captions','Legendas','Gerar pelo Jarvis, importar SRT ou escrever.','legenda transcrição srt subtítulo'],
 ['fonts','Fontes e prévias','Testar tipos de letra e importar fontes próprias.','fonte tipografia teko gilroy ttf otf woff'],
 ['preedit','Pré-edição: cortar pausas','Detectar silêncio, revisar e aplicar os cortes.','silêncio cortar pausa espaços pré edição fala'],
 ['audio','Música no vídeo','Importar áudio ou inserir uma trilha pronta para exportar.','música som áudio trilha volume fade'],
 ['spotify','Spotify','Buscar músicas, artistas, álbuns e playlists.','spotify repertório biblioteca player'],
 ['voice','Gravar voz','Gravar sua narração no navegador.','voz microfone narração gravar'],
 ['spatial','Projetos 3D','Importar projetos originais e adicionar texto espacial.','3d profundidade parallax perspectiva'],
 ['perspective','Texto em perspectiva','Inclinar o texto como parede, chão ou plano frontal.','texto 3d chão parede profundidade inclinar perspectiva'],
 ['behind','Texto atrás da pessoa','Organizar texto e personagem em planos diferentes.','texto atrás personagem fonte baixo cima pessoa'],
 ['references','Instagram, YouTube e referências','Guardar links, arquivos e orientações da cena.','instagram youtube referências captura link'],
 ['scene','Cenários e ambientes','Guardar um ambiente para reutilizar nas edições.','ambiente cenário clone fundo'],
 ['split','Dividir clipe','Cortar a camada na posição atual do cursor.','cortar dividir separar tesoura'],
 ['duplicate','Duplicar camada','Criar uma cópia editável do elemento selecionado.','duplicar cópia camada'],
 ['effects','Efeitos e animação','Ajustar movimento, cor e composição da camada.','efeitos animação cor chroma keyframe'],
 ['save','Baixar projeto','Guardar edição, mídias e fontes no arquivo .jarvis.','salvar baixar projeto backup continuar'],
 ['cloud','Salvar na nuvem','Guardar o projeto privado e seus arquivos usados.','nuvem salvar persistir'],
 ['export','Exportar vídeo','Baixar vídeo, imagem PNG ou legendas SRT.','exportar renderizar mp4 webm png srt baixar vídeo'],
 ['help','Como usar o editor','Consultar o passo a passo de edição.','ajuda tutorial como usar']
].map(([id,title,description,keywords])=>({id:'local:'+id,action:id,title,description,keywords,mode:'No editor'}));
const plain=value=>String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR').replace(/[^\p{L}\p{N}\s]/gu,' ');
const functionAliases={transcribe:'transcrição transcrever fala texto',captions:'legendar legenda legendas transcrição srt',narration:'narrar narração voz',preedit:'pré edição remover espaços vazios vícios erros repetições fala',isolate:'ruído limpar isolamento voz',dubbing:'dublar dublagem traduzir tradução',music:'trilha som música compor',environment:'tirar trocar cenário fundo', 'remove-bg':'remover tirar fundo recorte pessoa', 'person-cutout':'recortar recorte pessoa personagem fundo', 'own-voice':'clonar clone voz própria', 'voice-change':'trocar mudar voz', 'spatial-3d':'perspectiva profundidade texto 3d', 'flying-text':'texto fonte zoom câmera', 'youtube-capture':'capturar importar vídeo youtube', 'social-capture':'capturar importar instagram post página', 'scene-swap':'mudar trocar tirar fundo cenário'};
export function functionIndex(modules){return [...localFunctions,...modules.flatMap(m=>m.cards.map(c=>({id:'module:'+m.id+':'+c[0],module:m.id,action:c[0],title:c[1],description:c[2],keywords:m.title+' '+(functionAliases[c[0]]||''),mode:c[3]==='local'?'No editor':'Pelo Jarvis no chat'})))];}
export function findFunctions(index,query){const stop=new Set(['o','os','a','as','de','da','do','das','dos','para','com','e','um','uma','meu','minha','quero','fazer']);const words=plain(query).trim().split(/\s+/).filter(w=>w&&!stop.has(w));return index.map((item,i)=>{const title=plain(item.title),hay=plain([item.title,item.description,item.keywords].join(' '));if(!words.every(w=>hay.includes(w)))return null;return {item,i,score:words.reduce((n,w)=>n+(title.includes(w)?3:1),0)};}).filter(Boolean).sort((a,b)=>b.score-a.score||a.i-b.i).map(r=>r.item);}
const groupState=new Map();
export function functionTone(item){
 const modules={production:'rose',video:'blue',audio:'green',spatial:'violet',references:'orange',brand:'rose',trends:'orange',metrics:'cyan',operations:'blue',library:'blue',connections:'violet'};
 const local={text:'amber',captions:'amber',fonts:'amber',audio:'green',spotify:'green',voice:'green',spatial:'violet',perspective:'violet',behind:'violet',references:'orange',scene:'orange',preedit:'orange',effects:'violet',import:'blue',new:'blue',save:'blue',cloud:'blue',export:'cyan'};
 return item.module?modules[item.module]||'cyan':local[item.action]||'cyan';
}
export function groupPropertyControls(root,kind){
 for(const group of root.querySelectorAll('.property-group')){const heading=group.querySelector('h3');if(!heading)continue;const name=heading.textContent,key=kind+':'+name,details=document.createElement('details'),summary=document.createElement('summary');details.className='property-group property-disclosure';details.dataset.group=name;summary.textContent=name;heading.remove();details.append(summary,...group.childNodes);details.open=groupState.get(key)??['Texto','Forma','Posição e tamanho','Imagem','Áudio'].includes(name);details.addEventListener('toggle',()=>groupState.set(key,details.open));group.replaceWith(details);}
}
export function openPropertyGroup(root,name){const group=[...root.querySelectorAll('details[data-group]')].find(g=>g.dataset.group===name);if(group){group.open=true;group.scrollIntoView({behavior:'smooth',block:'nearest'});}return !!group;}
export function installTaskTabs(dialog,groups,label){
 const tabs=document.createElement('div');tabs.className='task-tabs';tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label',label);const panels=[];
 function select(id){groups.forEach((group,i)=>{const active=group.id===id;panels[i].hidden=!active;tabs.children[i].setAttribute('aria-selected',String(active));tabs.children[i].tabIndex=active?0:-1;});}
 for(const group of groups){const button=document.createElement('button'),panel=document.createElement('section');button.id=dialog.id+'-tab-'+group.id;button.type='button';button.textContent=group.title;button.setAttribute('role','tab');button.setAttribute('aria-controls',dialog.id+'-panel-'+group.id);panel.id=dialog.id+'-panel-'+group.id;panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',button.id);panel.append(...group.nodes);button.onclick=()=>select(group.id);tabs.append(button);panels.push(panel);dialog.append(panel);}
 tabs.addEventListener('keydown',event=>{const keys=['ArrowLeft','ArrowRight','Home','End'];if(!keys.includes(event.key))return;const buttons=[...tabs.children],i=buttons.indexOf(document.activeElement);if(i<0)return;event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(i+(event.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;select(groups[next].id);buttons[next].focus();});
 dialog.querySelector('form').after(tabs);select(groups[0].id);return select;
}
