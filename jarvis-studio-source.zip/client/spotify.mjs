const authKey='jarvis.spotify.pending',tokenKey='jarvis.spotify.session';
export const spotifyScopes='user-library-read playlist-read-private';
export function spotifyLink(raw){
 const uri=String(raw).trim().match(/^spotify:(track|playlist|album|artist):([a-zA-Z0-9]{22})$/);
 if(uri)return {kind:uri[1],id:uri[2],url:`https://open.spotify.com/${uri[1]}/${uri[2]}`};
 const u=new URL(raw);if(u.protocol!=='https:'||u.hostname!=='open.spotify.com'||u.username||u.password||u.port)throw Error('Use um link de música, álbum, artista ou playlist de open.spotify.com.');
 const m=u.pathname.match(/^\/(?:intl-[a-z-]+\/)?(track|playlist|album|artist)\/([a-zA-Z0-9]{22})\/?$/);if(!m)throw Error('Use o link de uma música, álbum, artista ou playlist específica.');
 return {kind:m[1],id:m[2],url:`https://open.spotify.com/${m[1]}/${m[2]}`};
}
export function audioPlacement(a,input){
 const n=k=>Number(input[k]);if(!Number.isFinite(a.duration)||a.duration<=0)throw Error('Duração do áudio inválida.');
 if(!Number.isFinite(n('offset'))||n('offset')<0||n('offset')>=a.duration)throw Error('O início do trecho deve estar dentro do arquivo de áudio.');
 if(!Number.isFinite(n('start'))||n('start')<0||n('start')>=86400||!Number.isFinite(n('duration'))||n('duration')<=0)throw Error('Informe entrada e duração válidas.');
 const duration=Math.min(n('duration'),a.duration-n('offset'),86400-n('start'));
 return {start:n('start'),offset:n('offset'),duration,volume:Math.max(0,Math.min(2,n('volume')/100||0)),fadeIn:Math.min(duration,Math.max(0,n('fadeIn')||0)),fadeOut:Math.min(duration,Math.max(0,n('fadeOut')||0))};
}
function b64(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');}
export function spotifyEmbedURL(raw){const s=spotifyLink(raw);return `https://open.spotify.com/embed/${s.kind}/${s.id}`;}
export function catalogEntry(item,type){
 if(!item||item.is_local||item.type!==type)return null;
 let s;try{s=spotifyLink(item.external_urls?.spotify||`https://open.spotify.com/${type}/${item.id}`);if(s.kind!==type)return null;}catch{return null;}
 const artists=Array.isArray(item.artists)?item.artists.map(a=>String(a.name||'')).join(', '):'';
 return {...s,name:String(item.name||'Sem título').slice(0,300),detail:type==='artist'?'Artista':type==='playlist'?String(item.owner?.display_name||'Playlist'):artists,duration:Math.max(0,Number(item.duration_ms)||0)/1000};
}
export function libraryEntry(item,kind){
 const t=kind==='playlists'?item:item?.track||item?.item;if(!t||!t.id||t.is_local||t.type==='episode')return null;
 let source;try{source=spotifyLink(t.external_urls?.spotify||`https://open.spotify.com/${kind==='playlists'?'playlist':'track'}/${t.id}`);}catch{return null;}
 if(source.kind!==(kind==='playlists'?'playlist':'track'))return null;
 return {...source,name:String(t.name||'Sem título').slice(0,300),detail:kind==='playlists'?String(t.owner?.display_name||''):Array.isArray(t.artists)?t.artists.map(a=>a.name).join(', '):'',duration:Math.max(0,Number(t.duration_ms)||0)/1000};
}
// Public application identifier; PKCE never uses a Client Secret.
export const spotifyDefaultClientId='c47140ef1f3146de97e4e57ee22c0325';
export class SpotifyConnection{
 constructor(storage,fetcher=(...args)=>fetch(...args),now=()=>Date.now()){this.storage=storage;this.fetcher=fetcher;this.now=now;this.epoch=0;this.refreshing=null;this.retryAt=0;}
 read(key){try{return JSON.parse(this.storage.getItem(key)||'null');}catch{return null;}}
 get connected(){return !!this.read(tokenKey)?.access_token;}
 disconnect(){this.epoch++;this.storage.removeItem(authKey);this.storage.removeItem(tokenKey);this.refreshing=null;}
 async begin(clientId,origin,projectId){
  if(!/^[a-fA-F0-9]{32}$/.test(clientId||''))throw Error('Informe o Client ID público do seu aplicativo Spotify. Não use Client Secret.');
  const site=new URL(origin);if(site.protocol!=='https:'||site.origin!==origin)throw Error('Conexão requer a origem HTTPS do editor.');
  this.disconnect();
  const verifier=b64(crypto.getRandomValues(new Uint8Array(64))),state=b64(crypto.getRandomValues(new Uint8Array(32))),redirectUri=origin+'/spotify-callback';
  const challenge=b64(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier)));
  const pending={verifier,state,clientId,redirectUri,projectId,createdAt:this.now()};this.storage.setItem(authKey,JSON.stringify(pending));
  const url=new URL('https://accounts.spotify.com/authorize');url.search=new URLSearchParams({response_type:'code',client_id:clientId,redirect_uri:redirectUri,scope:spotifyScopes,state,code_challenge_method:'S256',code_challenge:challenge}).toString();return url.href;
 }
 async finish(raw){
  const url=new URL(raw);if(url.pathname!=='/spotify-callback')return null;
  const p=this.read(authKey);this.storage.removeItem(authKey);const state=url.searchParams.get('state');
  if(!p||!state||state!==p.state||p.redirectUri!==url.origin+url.pathname||this.now()-p.createdAt>10*60*1000)throw Error('Autorização inválida ou expirada. Abra Áudio e tente conectar novamente.');
  if(url.searchParams.get('error'))return {projectId:p.projectId,message:'A conexão com o Spotify não foi autorizada.'};
  const code=url.searchParams.get('code');if(!code)return {projectId:p.projectId,message:'O Spotify não retornou a autorização.'};
  const epoch=this.epoch;
  try{const token=await this.token({grant_type:'authorization_code',code,redirect_uri:p.redirectUri,client_id:p.clientId,code_verifier:p.verifier});if(epoch!==this.epoch)return {projectId:p.projectId,message:'Conexão cancelada.'};this.writeToken(token,p.clientId);return {projectId:p.projectId,message:'Spotify autorizado. Busque no catálogo e consulte sua biblioteca em Áudio.'};}
  catch(e){return {projectId:p.projectId,message:e.message};}
 }
 async token(params){
  const response=await this.fetcher('https://accounts.spotify.com/api/token',{method:'POST',redirect:'error',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(params),signal:AbortSignal.timeout(15000)});
  if(!response.ok)throw Error('Não foi possível autorizar o Spotify. Confira o aplicativo, Client ID e URL de retorno no painel Spotify.');const t=await response.json();if(!t.access_token||t.token_type?.toLowerCase()!=='bearer'||!Number.isFinite(Number(t.expires_in)))throw Error('Resposta de autorização inválida.');return t;
 }
 writeToken(t,clientId,previous){this.storage.setItem(tokenKey,JSON.stringify({access_token:t.access_token,refresh_token:t.refresh_token||previous?.refresh_token,clientId,expiresAt:this.now()+Number(t.expires_in)*1000}));}
 async access(){
  const t=this.read(tokenKey);if(!t)throw Error('Conecte o Spotify para consultar sua biblioteca.');
  if(t.expiresAt>this.now()+30000)return t.access_token;
  if(!t.refresh_token){this.disconnect();throw Error('A autorização expirou. Conecte novamente.');}
  if(!this.refreshing){const epoch=this.epoch;this.refreshing=this.token({grant_type:'refresh_token',refresh_token:t.refresh_token,client_id:t.clientId}).then(next=>{if(epoch!==this.epoch)throw Error('Conexão cancelada.');this.writeToken(next,t.clientId,t);return next.access_token;}).catch(e=>{if(epoch===this.epoch)this.disconnect();throw e;}).finally(()=>{if(epoch===this.epoch)this.refreshing=null;});}
  return this.refreshing;
 }
 async page(kind,offset=0,playlistId=null){
  if(!['saved','playlists','playlist'].includes(kind))throw Error('Consulta de biblioteca inválida.');
  if(!Number.isInteger(offset)||offset<0||offset>100000)throw Error('Página inválida.');
  if(kind==='playlist'&&!/^[a-zA-Z0-9]{22}$/.test(playlistId||''))throw Error('Playlist inválida.');
  if(this.retryAt>this.now())throw Error(`Spotify pediu uma pausa. Tente em ${Math.ceil((this.retryAt-this.now())/1000)} segundos.`);
  const epoch=this.epoch,token=await this.access();if(epoch!==this.epoch)throw Error('Conexão cancelada.');
  const path=kind==='saved'?'/me/tracks':kind==='playlists'?'/me/playlists':`/playlists/${playlistId}/items`;
  const response=await this.fetcher(`https://api.spotify.com/v1${path}?limit=50&offset=${offset}`,{method:'GET',redirect:'error',headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(15000)});
  if(epoch!==this.epoch)throw Error('Conexão cancelada.');
  if(!response.ok){if(response.status===401)this.disconnect();if(response.status===429){const seconds=Math.max(1,Math.min(3600,Number(response.headers.get('Retry-After'))||30));this.retryAt=this.now()+seconds*1000;throw Error(`Limite Spotify. Tente novamente em ${seconds} segundos.`);}throw Error(response.status===403?'O Spotify não liberou esta consulta. Confira usuários autorizados, permissões e se a playlist é sua ou colaborativa.':'Falha ao consultar o Spotify. Reconecte se a sessão expirou.');}
  const data=await response.json();if(epoch!==this.epoch)throw Error('Conexão cancelada.');
  return {items:(data.items||[]).map(x=>libraryEntry(x,kind)).filter(Boolean),offset,total:Number(data.total)||0,hasMore:!!data.next};
 }
 async search(query,type='track',offset=0){
  const q=String(query||'').trim();if(!q||q.length>250||/[\u0000-\u001f]/.test(q))throw Error('Digite uma busca de 1 a 250 caracteres.');
  if(!['track','album','artist','playlist'].includes(type))throw Error('Tipo de busca inválido.');
  if(!Number.isInteger(offset)||offset<0||offset>1000)throw Error('Fim das páginas disponíveis. Refine sua busca.');
  if(this.retryAt>this.now())throw Error(`Spotify pediu uma pausa. Tente em ${Math.ceil((this.retryAt-this.now())/1000)} segundos.`);
  const epoch=this.epoch,token=await this.access();if(epoch!==this.epoch)throw Error('Conexão cancelada.');
  const params=new URLSearchParams({q,type,limit:'10',offset:String(offset),market:'BR'});
  const response=await this.fetcher('https://api.spotify.com/v1/search?'+params,{method:'GET',redirect:'error',headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(15000)});
  if(epoch!==this.epoch)throw Error('Conexão cancelada.');
  if(!response.ok){if(response.status===401)this.disconnect();if(response.status===429){const seconds=Math.max(1,Math.min(3600,Number(response.headers.get('Retry-After'))||30));this.retryAt=this.now()+seconds*1000;throw Error(`Limite Spotify. Tente novamente em ${seconds} segundos.`);}throw Error(response.status===403?'O Spotify não liberou a busca. Confira os requisitos do aplicativo e usuários autorizados.':'Falha na busca Spotify. Tente novamente.');}
  const data=await response.json();if(epoch!==this.epoch)throw Error('Conexão cancelada.');const page=data[type+'s'];if(!page||!Array.isArray(page.items))throw Error('Resposta de busca inválida.');
  return {items:page.items.map(t=>catalogEntry(t,type)).filter(Boolean),offset,total:Number(page.total)||0,hasMore:!!page.next&&offset<1000,limited:!!page.next&&offset>=1000};
 }
}
export function musicReferenceList(raw){
 const data=typeof raw==='string'?JSON.parse(raw):raw,rows=Array.isArray(data)?data:data?.references;if(!Array.isArray(rows)||!rows.length||rows.length>100)throw Error('Use JSON com 1 a 100 referências, contendo url e label opcional.');
 const seen=new Set();return rows.map(r=>{const s=spotifyLink(r.url);if(seen.has(s.url))return null;seen.add(s.url);return {...s,label:String(r.label||'Referência Spotify').slice(0,100)};}).filter(Boolean);
}
