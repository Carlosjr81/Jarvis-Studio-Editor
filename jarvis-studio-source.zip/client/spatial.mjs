// Project a flat text plane into a camera view. This is graphic perspective,
// not automatic tracking or a segmented person.
export function projectPoint(x,y,{tiltX=0,tiltY=0,depth=0}={}){
 const a=tiltX*Math.PI/180,b=tiltY*Math.PI/180,yy=y*Math.cos(a),zz=y*Math.sin(a),xx=x*Math.cos(b)+zz*Math.sin(b),z=-x*Math.sin(b)+zz*Math.cos(b)+depth;
 const factor=1800/Math.max(400,1800+z);return {x:xx*factor,y:yy*factor};
}
function triangle(ctx,img,s,d){
 const [a,b,c]=s,[p,q,r]=d,det=(b.x-a.x)*(c.y-a.y)-(c.x-a.x)*(b.y-a.y);if(Math.abs(det)<1e-6)return;
 const ax=((q.x-p.x)*(c.y-a.y)-(r.x-p.x)*(b.y-a.y))/det,bx=((r.x-p.x)*(b.x-a.x)-(q.x-p.x)*(c.x-a.x))/det;
 const ay=((q.y-p.y)*(c.y-a.y)-(r.y-p.y)*(b.y-a.y))/det,by=((r.y-p.y)*(b.x-a.x)-(q.y-p.y)*(c.x-a.x))/det;
 ctx.save();ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.lineTo(r.x,r.y);ctx.closePath();ctx.clip();ctx.transform(ax,ay,bx,by,p.x-ax*a.x-bx*a.y,p.y-ay*a.x-by*a.y);ctx.drawImage(img,0,0);ctx.restore();
}
export function drawPerspective(ctx,img,settings){
 const cols=12,rows=6,w=img.width,h=img.height;
 for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){
  const a={x:i*w/cols,y:j*h/rows},b={x:(i+1)*w/cols,y:j*h/rows},c={x:(i+1)*w/cols,y:(j+1)*h/rows},d={x:i*w/cols,y:(j+1)*h/rows};
  const proj=p=>projectPoint(p.x-w/2,p.y-h/2,settings);triangle(ctx,img,[a,b,c],[proj(a),proj(b),proj(c)]);triangle(ctx,img,[a,c,d],[proj(a),proj(c),proj(d)]);
 }
}
export const fontFamilies=['Arial','Georgia','Impact','Verdana','Courier New','Trebuchet MS','Times New Roman'];
export const textStyles=[
 {id:'clean',name:'Limpo',props:{fontFamily:'Arial',fontSize:64,bold:true,color:'#ffffff',shadow:true,outline:false,background:false,tiltX:0,tiltY:0,depth:0}},
 {id:'viral',name:'Legenda viral',props:{fontFamily:'Impact',fontSize:62,bold:true,color:'#ffe54e',shadow:true,outline:true,background:false}},
 {id:'cinema',name:'Cinema',props:{fontFamily:'Georgia',fontSize:74,bold:false,color:'#ffffff',shadow:true,outline:false,background:false}},
 {id:'boxed',name:'Caixa',props:{fontFamily:'Arial',fontSize:58,bold:true,color:'#ffffff',shadow:false,outline:false,background:true}},
 {id:'gavioes',name:'Gaviões · chamada',props:{fontFamily:'Impact',fontSize:84,bold:true,color:'#fe0006',shadow:true,outline:true,background:false}},
 {id:'spatial',name:'Espacial',props:{fontFamily:'Impact',fontSize:96,bold:true,color:'#20d6d0',opacity:.82,shadow:true,background:false,tiltX:-18,tiltY:28,depth:100,animation:'zoom'}}
];
